import os
import glob

for index, oldfile in enumerate(glob.glob("*.jpg"), start=1):
    newfile = 'english_'+'{}.jpg'.format(index)
    os.rename(oldfile, newfile)
